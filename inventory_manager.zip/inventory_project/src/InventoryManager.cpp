#include "InventoryManager.h"
#include <algorithm>
#include <iostream>
#include <iomanip>
#include <limits>
#include <cstring>

/* ------------------------------------------------------------------ */
/* Constructor / Destructor                                              */
/* ------------------------------------------------------------------ */

InventoryManager::InventoryManager() {}
InventoryManager::~InventoryManager() {}

/* ------------------------------------------------------------------ */
/* Input helpers                                                          */
/* ------------------------------------------------------------------ */

static int read_positive_int(const std::string &prompt)
{
    int val;
    while (true) {
        std::cout << prompt;
        if (std::cin >> val && val > 0) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return val;
        }
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "  [!] Invalid input. Must be a positive integer. Try again.\n";
    }
}

static int read_non_negative_int(const std::string &prompt)
{
    int val;
    while (true) {
        std::cout << prompt;
        if (std::cin >> val && val >= 0) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return val;
        }
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "  [!] Invalid input. Must be 0 or more. Try again.\n";
    }
}

static float read_non_negative_float(const std::string &prompt)
{
    float val;
    while (true) {
        std::cout << prompt;
        if (std::cin >> val && val >= 0.0f) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return val;
        }
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        std::cout << "  [!] Invalid input. Must be 0 or more. Try again.\n";
    }
}

static std::string read_non_empty_string(const std::string &prompt)
{
    std::string val;
    while (true) {
        std::cout << prompt;
        std::getline(std::cin, val);
        if (!val.empty()) return val;
        std::cout << "  [!] Name must not be empty. Try again.\n";
    }
}

/* ------------------------------------------------------------------ */
/* Public methods                                                         */
/* ------------------------------------------------------------------ */

void InventoryManager::addItem()
{
    std::cout << "\n--- Add New Item ---\n";
    Item item{};

    item.id       = read_positive_int("  Enter ID (positive integer): ");
    std::string name = read_non_empty_string("  Enter name (max 39 chars): ");
    // Truncate safely
    strncpy(item.name, name.c_str(), 39);
    item.name[39] = '\0';
    item.quantity  = read_non_negative_int("  Enter quantity (>= 0): ");
    item.price     = read_non_negative_float("  Enter price (>= 0.00): ");
    item.is_deleted = 0;

    if (add_item(&item)) {
        std::cout << "  [OK] Item added successfully.\n";
    } else {
        std::cout << "  [!] Failed: duplicate active ID or file error.\n";
    }
}

void InventoryManager::viewItem()
{
    std::cout << "\n--- View Item by ID ---\n";
    int id = read_positive_int("  Enter ID: ");
    Item item{};

    if (get_item(id, &item)) {
        printItem(item);
    } else {
        std::cout << "  [!] Item with ID " << id << " not found (or deleted).\n";
    }
}

void InventoryManager::updateItem()
{
    std::cout << "\n--- Update Item ---\n";
    int id = read_positive_int("  Enter ID to update: ");

    Item existing{};
    if (!get_item(id, &existing)) {
        std::cout << "  [!] Item with ID " << id << " not found (or deleted).\n";
        return;
    }

    std::cout << "  Current record:\n";
    printItem(existing);

    Item updated{};
    updated.id = id;

    std::string name = read_non_empty_string("  New name (max 39 chars): ");
    strncpy(updated.name, name.c_str(), 39);
    updated.name[39] = '\0';
    updated.quantity  = read_non_negative_int("  New quantity (>= 0): ");
    updated.price     = read_non_negative_float("  New price (>= 0.00): ");
    updated.is_deleted = 0;

    if (update_item(id, &updated)) {
        std::cout << "  [OK] Item updated successfully.\n";
    } else {
        std::cout << "  [!] Update failed.\n";
    }
}

void InventoryManager::deleteItem()
{
    std::cout << "\n--- Delete Item ---\n";
    int id = read_positive_int("  Enter ID to delete: ");

    if (delete_item(id)) {
        std::cout << "  [OK] Item " << id << " deleted (soft-delete).\n";
    } else {
        std::cout << "  [!] Item with ID " << id << " not found (or already deleted).\n";
    }
}

void InventoryManager::listItems(SortOrder order)
{
    std::cout << "\n--- List All Items ---\n";
    const int MAX = 1000;
    std::vector<Item> items(MAX);

    int count = list_items(items.data(), MAX);
    if (count == 0) {
        std::cout << "  (No active items in inventory.)\n";
        return;
    }
    items.resize(count);

    // Sort
    if (order == SortOrder::BY_NAME) {
        std::sort(items.begin(), items.end(), [](const Item &a, const Item &b) {
            return std::string(a.name) < std::string(b.name);
        });
        std::cout << "  (Sorted by name)\n";
    } else {
        std::sort(items.begin(), items.end(), [](const Item &a, const Item &b) {
            return a.id < b.id;
        });
        std::cout << "  (Sorted by ID)\n";
    }

    // Header
    std::cout << "\n  " << std::left
              << std::setw(6)  << "ID"
              << std::setw(42) << "Name"
              << std::setw(10) << "Qty"
              << std::setw(12) << "Price"
              << "\n";
    std::cout << "  " << std::string(70, '-') << "\n";

    for (const auto &item : items) {
        std::cout << "  "
                  << std::left  << std::setw(6)  << item.id
                  << std::left  << std::setw(42) << item.name
                  << std::left  << std::setw(10) << item.quantity
                  << std::right << std::fixed << std::setprecision(2)
                  << "$" << item.price
                  << "\n";
    }
    std::cout << "  " << std::string(70, '-') << "\n";
    std::cout << "  Total active items: " << count << "\n";
}

/* ------------------------------------------------------------------ */
/* Private helpers                                                        */
/* ------------------------------------------------------------------ */

void InventoryManager::printItem(const Item &item) const
{
    std::cout << "\n  +---------------------------------+\n";
    std::cout << "  | ID       : " << std::left << std::setw(22) << item.id       << "|\n";
    std::cout << "  | Name     : " << std::left << std::setw(22) << item.name     << "|\n";
    std::cout << "  | Quantity : " << std::left << std::setw(22) << item.quantity  << "|\n";
    std::cout << "  | Price    : $" << std::left << std::setw(21)
              << std::fixed << std::setprecision(2) << item.price << "|\n";
    std::cout << "  | Status   : " << std::left << std::setw(22)
              << (item.is_deleted ? "DELETED" : "Active") << "|\n";
    std::cout << "  +---------------------------------+\n";
}
