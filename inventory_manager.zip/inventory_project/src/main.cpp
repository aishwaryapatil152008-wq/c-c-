#include <iostream>
#include <limits>
#include "InventoryManager.h"

static void printMenu()
{
    std::cout << "\n========================================\n";
    std::cout << "   Hybrid Inventory Manager\n";
    std::cout << "========================================\n";
    std::cout << "  1. Add Item\n";
    std::cout << "  2. View Item\n";
    std::cout << "  3. Update Item\n";
    std::cout << "  4. Delete Item\n";
    std::cout << "  5. List All  (sort by ID)\n";
    std::cout << "  5n. List All (sort by Name)\n";
    std::cout << "  6. Exit\n";
    std::cout << "----------------------------------------\n";
    std::cout << "  Choice: ";
}

int main()
{
    InventoryManager mgr;
    std::string choice;

    while (true) {
        printMenu();
        std::cin >> choice;
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

        if (choice == "1") {
            mgr.addItem();
        } else if (choice == "2") {
            mgr.viewItem();
        } else if (choice == "3") {
            mgr.updateItem();
        } else if (choice == "4") {
            mgr.deleteItem();
        } else if (choice == "5") {
            mgr.listItems(SortOrder::BY_ID);
        } else if (choice == "5n" || choice == "5N") {
            mgr.listItems(SortOrder::BY_NAME);
        } else if (choice == "6") {
            std::cout << "\n  Goodbye!\n\n";
            break;
        } else {
            std::cout << "\n  [!] Unknown option. Please enter 1-6 (or 5n for name sort).\n";
        }
    }

    return 0;
}
