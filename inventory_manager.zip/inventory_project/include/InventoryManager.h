#ifndef INVENTORY_MANAGER_H
#define INVENTORY_MANAGER_H

#include <vector>
#include <string>
#include "inventory.h"   /* C struct + function declarations */

enum class SortOrder { BY_ID, BY_NAME };

/**
 * InventoryManager
 * C++ wrapper around the C inventory backend.
 * Handles user interaction, STL containers, and sorted display.
 */
class InventoryManager {
public:
    InventoryManager();
    ~InventoryManager();

    /** Prompt user for new item data and call add_item(). */
    void addItem();

    /** Prompt for an ID and display the matching item. */
    void viewItem();

    /** Prompt for an ID and new data, then call update_item(). */
    void updateItem();

    /** Prompt for an ID and call delete_item() (soft delete). */
    void deleteItem();

    /**
     * Fetch all active items into a std::vector, sort by ID or name,
     * and print a formatted table.
     */
    void listItems(SortOrder order = SortOrder::BY_ID);

private:
    /** Pretty-print a single Item record. */
    void printItem(const Item &item) const;
};

#endif /* INVENTORY_MANAGER_H */
