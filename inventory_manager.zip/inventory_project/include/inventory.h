#ifndef INVENTORY_H
#define INVENTORY_H

#ifdef __cplusplus
extern "C" {
#endif

/* Item data structure */
typedef struct {
    int id;
    char name[40];
    int quantity;
    float price;
    int is_deleted; /* 0 = active, 1 = deleted */
} Item;

/**
 * Add a new item to the inventory file.
 * Returns 1 on success, 0 on failure (e.g., duplicate ID).
 */
int add_item(const Item *item);

/**
 * Retrieve an item by ID into 'out'.
 * Returns 1 on success, 0 if not found or deleted.
 */
int get_item(int id, Item *out);

/**
 * Update an existing (non-deleted) record by ID.
 * Returns 1 on success, 0 if not found or deleted.
 */
int update_item(int id, const Item *updated);

/**
 * Soft-delete an item by ID (sets is_deleted = 1).
 * Returns 1 on success, 0 if not found or already deleted.
 */
int delete_item(int id);

/**
 * Fill 'buffer' with up to max_items active (non-deleted) items.
 * Returns the number of items copied.
 */
int list_items(Item *buffer, int max_items);

#ifdef __cplusplus
}
#endif

#endif /* INVENTORY_H */
