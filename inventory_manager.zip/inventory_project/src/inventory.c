#include "inventory.h"
#include <stdio.h>
#include <string.h>

#define DATA_FILE "inventory.dat"

/* ------------------------------------------------------------------ */
/* Internal helpers                                                      */
/* ------------------------------------------------------------------ */

/** Open the data file; create it if it doesn't exist. */
static FILE *open_file(const char *mode)
{
    FILE *fp = fopen(DATA_FILE, mode);
    if (!fp && mode[0] == 'r') {
        /* File doesn't exist yet – create it empty, then re-open */
        fp = fopen(DATA_FILE, "wb");
        if (fp) fclose(fp);
        fp = fopen(DATA_FILE, mode);
    }
    return fp;
}

/** Return the byte offset of a record (0-based index). */
static long record_offset(long index)
{
    return index * (long)sizeof(Item);
}

/** Count total records (including deleted) in the file. */
static long total_records(FILE *fp)
{
    fseek(fp, 0, SEEK_END);
    long size = ftell(fp);
    return size / (long)sizeof(Item);
}

/* ------------------------------------------------------------------ */
/* Public API                                                            */
/* ------------------------------------------------------------------ */

int add_item(const Item *item)
{
    if (!item || item->id <= 0)
        return 0;

    /* Open for read+write (binary); create if absent */
    FILE *fp = open_file("r+b");
    if (!fp) {
        fp = fopen(DATA_FILE, "w+b");
        if (!fp) return 0;
    }

    long count = total_records(fp);
    Item tmp;

    /* Check for duplicate ID */
    for (long i = 0; i < count; i++) {
        fseek(fp, record_offset(i), SEEK_SET);
        if (fread(&tmp, sizeof(Item), 1, fp) == 1) {
            if (tmp.id == item->id && !tmp.is_deleted) {
                fclose(fp);
                return 0; /* duplicate active ID */
            }
        }
    }

    /* Append new record */
    fseek(fp, 0, SEEK_END);
    int ok = (fwrite(item, sizeof(Item), 1, fp) == 1);
    fclose(fp);
    return ok;
}

int get_item(int id, Item *out)
{
    if (!out || id <= 0) return 0;

    FILE *fp = open_file("rb");
    if (!fp) return 0;

    long count = total_records(fp);
    Item tmp;
    int found = 0;

    for (long i = 0; i < count; i++) {
        fseek(fp, record_offset(i), SEEK_SET);
        if (fread(&tmp, sizeof(Item), 1, fp) == 1) {
            if (tmp.id == id && !tmp.is_deleted) {
                *out = tmp;
                found = 1;
                break;
            }
        }
    }

    fclose(fp);
    return found;
}

int update_item(int id, const Item *updated)
{
    if (!updated || id <= 0) return 0;

    FILE *fp = open_file("r+b");
    if (!fp) return 0;

    long count = total_records(fp);
    Item tmp;
    int found = 0;

    for (long i = 0; i < count; i++) {
        fseek(fp, record_offset(i), SEEK_SET);
        if (fread(&tmp, sizeof(Item), 1, fp) == 1) {
            if (tmp.id == id && !tmp.is_deleted) {
                /* Write updated record at same position */
                Item to_write = *updated;
                to_write.id = id;          /* preserve original ID */
                to_write.is_deleted = 0;   /* keep active */
                fseek(fp, record_offset(i), SEEK_SET);
                found = (fwrite(&to_write, sizeof(Item), 1, fp) == 1);
                break;
            }
        }
    }

    fclose(fp);
    return found;
}

int delete_item(int id)
{
    if (id <= 0) return 0;

    FILE *fp = open_file("r+b");
    if (!fp) return 0;

    long count = total_records(fp);
    Item tmp;
    int found = 0;

    for (long i = 0; i < count; i++) {
        fseek(fp, record_offset(i), SEEK_SET);
        if (fread(&tmp, sizeof(Item), 1, fp) == 1) {
            if (tmp.id == id && !tmp.is_deleted) {
                tmp.is_deleted = 1;
                fseek(fp, record_offset(i), SEEK_SET);
                found = (fwrite(&tmp, sizeof(Item), 1, fp) == 1);
                break;
            }
        }
    }

    fclose(fp);
    return found;
}

int list_items(Item *buffer, int max_items)
{
    if (!buffer || max_items <= 0) return 0;

    FILE *fp = open_file("rb");
    if (!fp) return 0;

    long count = total_records(fp);
    Item tmp;
    int copied = 0;

    for (long i = 0; i < count && copied < max_items; i++) {
        fseek(fp, record_offset(i), SEEK_SET);
        if (fread(&tmp, sizeof(Item), 1, fp) == 1) {
            if (!tmp.is_deleted) {
                buffer[copied++] = tmp;
            }
        }
    }

    fclose(fp);
    return copied;
}
